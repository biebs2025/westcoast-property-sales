import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { MapPin, Mail } from "lucide-react";

let nextId = 4;

export default function PropertySales() {
  const [search, setSearch] = useState("");
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([
    {
      id: 1,
      title: "Luxury Beachfront Home in Laaiplek",
      price: "R3,750,000",
      image: "/laaiplek-beach-home.jpg",
      location: "Laaiplek, West Coast",
      description: "Step out onto the dunes from this 3-bed home with uninterrupted views of the Atlantic Ocean."
    },
    {
      id: 2,
      title: "Elegant Coastal Villa in Atlantic Sands",
      price: "R2,900,000",
      image: "/atlantic-sands-villa.jpg",
      location: "Atlantic Sands Estate, Laaiplek",
      description: "Bright, airy 4-bedroom villa in secure estate with beach access and modern finishes."
    },
    {
      id: 3,
      title: "Charming Fisherman's Cottage",
      price: "R1,250,000",
      image: "/fishermans-cottage.jpg",
      location: "Laaiplek Harbour Area",
      description: "Historic 2-bedroom cottage a stroll from the river mouth. Ideal for peaceful weekends or retirement."
    }
  ]);

  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [newProperty, setNewProperty] = useState({
    title: "",
    price: "",
    image: "",
    location: "",
    description: ""
  });

  const filtered = properties.filter((p) =>
    p.title.toLowerCase().includes(search.toLowerCase()) ||
    p.location.toLowerCase().includes(search.toLowerCase())
  );

  const handleLogin = () => {
    if (loginForm.email && loginForm.password) {
      setUser({ email: loginForm.email });
    }
  };

  const handleSubmitProperty = () => {
    if (newProperty.title && newProperty.price) {
      setProperties([
        ...properties,
        { id: nextId++, ...newProperty }
      ]);
      setNewProperty({ title: "", price: "", image: "", location: "", description: "" });
    }
  };

  return (
    <div className="bg-gradient-to-br from-sky-100 to-yellow-100 min-h-screen p-4 max-w-7xl mx-auto">
      <header className="text-center py-10">
        <h1 className="text-5xl font-extrabold text-sky-700 drop-shadow-md">West Coast Property Sales</h1>
        <p className="text-lg text-sky-600 mt-3">Live the West Coast lifestyle—sun, sand, and serenity</p>
        <div className="mt-6 max-w-md mx-auto">
          <Input
            placeholder="Search by title or location"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="rounded-xl border-2 border-yellow-300 focus:border-sky-500"
          />
        </div>
        {!user && (
          <div className="mt-6 max-w-md mx-auto bg-white p-4 rounded-xl shadow-md">
            <h2 className="text-lg font-bold mb-2 text-sky-700">Login to Submit Properties</h2>
            <Input
              placeholder="Email"
              value={loginForm.email}
              onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
              className="mb-2"
            />
            <Input
              placeholder="Password"
              type="password"
              value={loginForm.password}
              onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
              className="mb-2"
            />
            <Button onClick={handleLogin} className="w-full bg-sky-500 text-white hover:bg-sky-600">Login</Button>
          </div>
        )}
        {user && (
          <div className="mt-6 text-sky-700">Welcome, {user.email}! <Button variant="link" onClick={() => setUser(null)}>Log Out</Button></div>
        )}
      </header>

      {user && (
        <section className="bg-white p-6 rounded-2xl shadow-lg mb-10">
          <h2 className="text-2xl font-bold text-sky-700 mb-4">Submit a New Property</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              placeholder="Title"
              value={newProperty.title}
              onChange={(e) => setNewProperty({ ...newProperty, title: e.target.value })}
            />
            <Input
              placeholder="Price"
              value={newProperty.price}
              onChange={(e) => setNewProperty({ ...newProperty, price: e.target.value })}
            />
            <Input
              placeholder="Image URL"
              value={newProperty.image}
              onChange={(e) => setNewProperty({ ...newProperty, image: e.target.value })}
            />
            <Input
              placeholder="Location"
              value={newProperty.location}
              onChange={(e) => setNewProperty({ ...newProperty, location: e.target.value })}
            />
            <textarea
              placeholder="Description"
              rows={3}
              className="md:col-span-2 p-3 rounded-xl border border-gray-300"
              value={newProperty.description}
              onChange={(e) => setNewProperty({ ...newProperty, description: e.target.value })}
            />
            <Button onClick={handleSubmitProperty} className="md:col-span-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-xl">Submit Property</Button>
          </div>
        </section>
      )}

      <main className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((property) => (
          <motion.div
            key={property.id}
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="overflow-hidden shadow-2xl rounded-2xl border border-yellow-300 bg-white">
              <img
                src={property.image}
                alt={property.title}
                className="h-56 w-full object-cover"
              />
              <CardContent className="p-5">
                <h2 className="text-2xl font-semibold text-sky-800">{property.title}</h2>
                <p className="text-yellow-600 font-bold text-lg mt-1">{property.price}</p>
                <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                  <MapPin className="w-4 h-4 text-sky-500" /> {property.location}
                </p>
                <p className="text-sm text-gray-700 mt-2">{property.description}</p>
                <Button className="mt-4 w-full bg-sky-500 hover:bg-sky-600 text-white">View Details</Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </main>

      <section className="mt-16 bg-white p-10 rounded-2xl shadow-xl">
        <h2 className="text-3xl font-bold text-sky-700 text-center mb-4">Contact Us</h2>
        <p className="text-center text-gray-600 mb-6 max-w-xl mx-auto">
          Whether you're buying or selling, we’re here to help you experience the West Coast dream. Reach out and let’s talk.
        </p>
        <form className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          <Input placeholder="Your Name" className="rounded-xl" />
          <Input placeholder="Your Email" className="rounded-xl" />
          <Input placeholder="Subject" className="md:col-span-2 rounded-xl" />
          <textarea placeholder="Your Message" rows={4} className="md:col-span-2 rounded-xl border border-gray-300 p-3"></textarea>
          <Button className="md:col-span-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-xl">Send Message</Button>
        </form>
      </section>

      <footer className="text-center text-gray-600 text-sm py-10 mt-16">
        <p>© {new Date().getFullYear()} West Coast Property Sales. All rights reserved.</p>
        <p className="mt-2 flex justify-center items-center gap-2 text-sky-600">
          <Mail className="w-4 h-4" /> hello@westcoastliving.com
        </p>
      </footer>
    </div>
  );
}
